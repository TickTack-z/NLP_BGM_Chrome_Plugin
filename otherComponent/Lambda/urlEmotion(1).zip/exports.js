'use strict';

console.log('Loading function');

var NaturalLanguageUnderstandingV1 = require('watson-developer-cloud/natural-language-understanding/v1.js');
var natural_language_understanding = new NaturalLanguageUnderstandingV1({
    'username': '9e7ac6c5-d7af-4e5f-9aa8-bd1977db378e',
    'password': '2M5Jq1Yvphpd',
    'version_date': '2017-02-27'
});

var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
AWS.config.update({ accessKeyId: 'AKIAJFP77Z7YWV6LISMQ', secretAccessKey: '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'});
var doc = require('dynamodb-doc');
var dynamodb = new doc.DynamoDB();






exports.handler = (event, context, callback) => {
    const body = JSON.parse(event.body);
    const url = body.URL;
    const userID = body.UserID;

    // const url = "http://www.bbc.com/news/world-europe-42374693";
    // const userID = "1430015097095899";

    const target = "a";
    const emotions = ["sadness", "joy", "fear", "disgust", "anger"]

    console.log(JSON.stringify({
        "body":{
            "url":url,
            "UserID":userID
        }
    }))
    var parameters = {
        'url': url,
        'features': {
            'emotion': {
                'targets': [
                    target
                ]
            }
        }

    };

    natural_language_understanding.analyze(parameters, function(err, response) {
        if (err)
            console.log('error:', err);
        else {
            // console.log(JSON.stringify(response, null, 2));
            var emotion = "sadness";
            var val = 0;
            var emotion_values = response.emotion.document.emotion;
            console.log("all emotions: " + JSON.stringify(emotion_values, null, 2));

            for (var i = 0; i < 4; i++) {
                if (emotion_values[emotions[i]] > val) {
                    emotion = emotions[i];
                    val = emotion_values[emotions[i]];
                }
            }
            console.log("cloest emotion: " + emotion);



            var dbparams = {};
            dbparams.TableName = "UserRating";

            dbparams.Key = {"UserID": userID};

            dynamodb.getItem(dbparams, function(err, data) {
                console.log("phase2");

                var num = Math.floor((Math.random() * 4) + 1);
                var urlMusic = "https://s3.amazonaws.com/emotion-music/" + emotion + "/" + emotion + num + ".mp3";
                if (err) {
                    console.log('error:', err);
                }
                else {
                    // console.log(data);
                    data = data.Item;
                    if (data != undefined && Math.random() < 0.7) {
                        var musics = [];
                        var score = -1;
                        for (var i = 1; i < 5; i++) {
                            var name = emotion + "" + i;
                            var s = data[name] + Math.random();
                            if (s < score) continue;
                            if (s > score) {
                                musics = [];
                                score = s;
                            }
                            musics.push(name);
                        }
                        console.log(musics);
                        var num = Math.floor(Math.random() * musics.length);
                        urlMusic = "https://s3.amazonaws.com/emotion-music/" + emotion + "/" + musics[num] + ".mp3";
                    }
                    console.log("music url: ", urlMusic);
                    callback(null, {
                        statusCode: 200,
                        body: JSON.stringify({
                            "urlMusic": urlMusic,
                            "emotions": emotion_values})
                    });
                }
            });
        }
    });

};
