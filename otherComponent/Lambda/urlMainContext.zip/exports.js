'use strict';

console.log('Loading function');

exports.handler = (event, context, callback) => {
    const url = event.body;
    var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
    var HttpClient = function() {
        this.get = function(aUrl, aCallback) {
            var anHttpRequest = new XMLHttpRequest();
            anHttpRequest.onreadystatechange = function() {
                if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
                    aCallback(anHttpRequest.responseText);
            }
    
            anHttpRequest.open( "GET", aUrl, true );
            anHttpRequest.send( null );
        }
    }
    
    var client = new HttpClient();
    client.get('https://api.diffbot.com/v3/analyze?token=479a58b6b1b142a968a01a998dffa32d&url='+url, function(response) {
        console.log(JSON.parse(response).objects[0].text);
        callback(null, {
                statusCode: 200,
                body: JSON.parse(response).objects[0].text
            });
    });
};
