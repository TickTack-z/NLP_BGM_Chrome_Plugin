'use strict';

console.log('Loading function');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var AWS = require('aws-sdk');
AWS.config.update({region:'us-east-1'});
AWS.config.update({ accessKeyId: 'AKIAJFP77Z7YWV6LISMQ', secretAccessKey: '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'});


var comprehend = new AWS.Comprehend();

exports.handler = (event, context, callback) =>
{
    const url = event.body;
    var HttpClient = function () {
        this.get = function (aUrl, aCallback) {
            var anHttpRequest = new XMLHttpRequest();
            anHttpRequest.onreadystatechange = function () {
                if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
                    aCallback(anHttpRequest.responseText);
            }

            anHttpRequest.open("GET", aUrl, true);
            anHttpRequest.send(null);
        }
    }

    var client = new HttpClient();
    client.get('https://api.diffbot.com/v3/analyze?token=479a58b6b1b142a968a01a998dffa32d&url=' + url, function (response) {
        var mainContent = JSON.parse(response).objects[0].text;
        console.log(mainContent);
        var params = {
            LanguageCode: "en",
            Text: mainContent
        };
        comprehend.detectEntities(params, function (err, data) {
            if (err) console.log(err, err.stack); // an error occurred
            else {
                // console.log(data);           // successful response
                var locations = [];
                var entities = data.Entities
                for (var i in entities) {
                    // console.log(data.Entities[i]);
                    if (entities [i].Type != 'LOCATION') continue;
                    locations.push(entities [i].Text);
                }
                locations = Array.from(new Set(locations))
                console.log(locations);
                callback(null, {
                    statusCode: 200,
                    body: JSON.stringify(locations)
                });
            }
        });
    });
};

